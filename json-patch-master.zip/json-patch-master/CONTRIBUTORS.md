## Ryan Lopopolo (https://github.com/lopopolo)

* Fix bug in JSON Patch add where target path is not a container node

## Randal Watler (watler@wispertel.net)

* "JSON Diff"

